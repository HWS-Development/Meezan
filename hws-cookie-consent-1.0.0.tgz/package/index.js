import * as consent from 'vanilla-cookieconsent';
import 'vanilla-cookieconsent/dist/cookieconsent.css';
import './site.css';

// This module is safe to import from shared SSR/client entries.
const browser = typeof window !== 'undefined' && typeof document !== 'undefined';
export const allowed = category => browser && consent.acceptedCategory(category);
export const showPreferences = () => browser && consent.showPreferences();

const copy = {
  fr: {
    title: 'Vos préférences de confidentialité',
    description: 'Les cookies nécessaires assurent le fonctionnement du site. Les cookies de mesure d’audience et de publicité sont facultatifs et restent désactivés sans votre accord. Vous pouvez modifier votre choix à tout moment depuis le bas de page.',
    accept: 'Tout accepter', reject: 'Refuser les cookies optionnels', settings: 'Personnaliser',
    preferences: 'Gestion des cookies', save: 'Enregistrer mes choix', close: 'Fermer',
    necessary: 'Strictement nécessaires', necessaryText: 'Toujours actifs : fonctionnement du site et mémorisation de vos préférences de confidentialité pendant six mois.',
    analytics: 'Mesure d’audience', analyticsText: 'Autoriser les outils de statistiques éventuellement configurés sur ce site. Aucun outil de cette catégorie ne doit être chargé avant votre accord.',
    marketing: 'Publicité', marketingText: 'Autoriser les outils publicitaires éventuellement configurés sur ce site et les cookies associés. Refuser n’empêche pas de consulter le site ou de réserver.',
  },
  en: {
    title: 'Your privacy preferences',
    description: 'Necessary cookies keep this website working. Analytics and advertising cookies are optional and stay disabled without your permission. You can change your choice at any time using the link in the footer.',
    accept: 'Accept all', reject: 'Reject optional cookies', settings: 'Customize',
    preferences: 'Cookie settings', save: 'Save my choices', close: 'Close',
    necessary: 'Strictly necessary', necessaryText: 'Always active: essential website functions and storage of your privacy preferences for six months.',
    analytics: 'Analytics', analyticsText: 'Allow any analytics tools configured on this website. Tools in this category must not load before your permission.',
    marketing: 'Advertising', marketingText: 'Allow any advertising tools configured on this website and their cookies. Rejecting does not prevent browsing or booking.',
  },
  es: {
    title: 'Sus preferencias de privacidad',
    description: 'Las cookies necesarias permiten el funcionamiento del sitio. Las cookies de estadísticas y publicidad son opcionales y permanecen desactivadas sin su permiso. Puede modificar su elección desde el pie de página.',
    accept: 'Aceptar todas', reject: 'Rechazar las cookies opcionales', settings: 'Personalizar',
    preferences: 'Gestionar cookies', save: 'Guardar mis preferencias', close: 'Cerrar',
    necessary: 'Estrictamente necesarias', necessaryText: 'Siempre activas: funciones esenciales y almacenamiento de sus preferencias de privacidad durante seis meses.',
    analytics: 'Estadísticas', analyticsText: 'Permitir las herramientas de estadísticas configuradas en este sitio, solo después de su autorización.',
    marketing: 'Publicidad', marketingText: 'Permitir las herramientas publicitarias configuradas en este sitio. Rechazarlas no impide navegar ni reservar.',
  },
};

const translations = Object.fromEntries(Object.entries(copy).map(([language, t]) => [language, {
  consentModal: {
    title: t.title, description: t.description,
    acceptAllBtn: t.accept, acceptNecessaryBtn: t.reject, showPreferencesBtn: t.settings,
  },
  preferencesModal: {
    title: t.preferences, acceptAllBtn: t.accept, acceptNecessaryBtn: t.reject,
    savePreferencesBtn: t.save, closeIconLabel: t.close,
    sections: [
      { title: t.title, description: t.description },
      { title: t.necessary, description: t.necessaryText, linkedCategory: 'necessary' },
      { title: t.analytics, description: t.analyticsText, linkedCategory: 'analytics' },
      { title: t.marketing, description: t.marketingText, linkedCategory: 'marketing' },
    ],
  },
}]));

function currentLanguage() {
  const route = window.location.pathname.match(/^\/(fr|en|es)(?:\/|$)/)?.[1];
  const language = document.documentElement.lang.toLowerCase().split('-')[0];
  return route || (copy[language] ? language : 'fr');
}

function notify() {
  window.dispatchEvent(new CustomEvent('hws:consent', {
    detail: { analytics: allowed('analytics'), marketing: allowed('marketing') },
  }));
}

// A loader must be registered here, rather than executed before consent.
export function whenAllowed(category, start) {
  if (!browser) return () => {};
  let started = false;
  const check = () => {
    if (!started && allowed(category)) { started = true; start(); }
  };
  window.addEventListener('hws:consent', check);
  ready.then(check);
  return () => window.removeEventListener('hws:consent', check);
}

export const ready = browser ? new Promise(resolve => {
  const init = async () => {
    // Browser-based prerenderers must not serialize interactive consent state.
    if (window.__HWS_PRERENDER__) { resolve(); return; }
    // Older static snapshots may contain a captured dialog, without its listeners.
    document.querySelectorAll('#cc-main, [data-hws-cookie-footer], [data-hws-cookie-settings]').forEach(element => element.remove());
    document.documentElement.classList.remove('show--consent', 'show--preferences', 'disable--interaction');
    await consent.run({
      revision: 1,
      hideFromBots: false,
      cookie: { name: 'hws_cookie_consent', expiresAfterDays: 182, sameSite: 'Lax' },
      guiOptions: {
        consentModal: { layout: 'box wide', position: 'bottom left', equalWeightButtons: true, flipButtons: false },
        preferencesModal: { layout: 'box', equalWeightButtons: true, flipButtons: false },
      },
      categories: {
        necessary: { enabled: true, readOnly: true },
        analytics: { autoClear: { cookies: [{ name: /^_ga/ }, { name: /^_gid$/ }, { name: /^_gat/ }, { name: /^_clck$/ }, { name: /^_clsk$/ }] } },
        marketing: { autoClear: { cookies: [{ name: /^_fbp$/ }, { name: /^_fbc$/ }, { name: /^_gcl_/ }] } },
      },
      language: { default: currentLanguage(), translations },
      onConsent: notify,
      onChange: ({ changedCategories }) => {
        // Reload after saving a withdrawal: removing a script element cannot stop
        // timers/listeners installed by a previously authorized third party.
        const revoked = changedCategories.some(category => category !== 'necessary' && !allowed(category));
        if (revoked) setTimeout(() => window.location.reload(), 0);
        else notify();
      },
    });
    window.hwsConsent = { allowed, showPreferences };
    document.getElementById('cc-main')?.addEventListener('click', event => event.stopPropagation());
    let language = currentLanguage();
    const sync = () => {
      const next = currentLanguage();
      if (next !== language) { language = next; consent.setLanguage(next); }
      // Keep this small legal footer outside the React hydration root. Mutating
      // server-rendered footer children before hydration causes React 418/423.
      let footer = document.querySelector('[data-hws-cookie-footer]');
      if (!footer) {
        footer = document.createElement('footer');
        footer.dataset.hwsCookieFooter = '';
        document.body.append(footer);
      }
      {
        let button = footer.querySelector('[data-hws-cookie-settings]');
        if (!button) {
          button = document.createElement('button');
          button.type = 'button';
          button.dataset.hwsCookieSettings = '';
          button.setAttribute('aria-haspopup', 'dialog');
          button.addEventListener('click', event => { event.stopPropagation(); showPreferences(); });
          footer.append(button);
        }
        if (button.textContent !== copy[language].preferences) button.textContent = copy[language].preferences;
      }
    };
    let scheduled = false;
    const observer = new MutationObserver(() => {
      if (scheduled) return;
      scheduled = true;
      queueMicrotask(() => { scheduled = false; sync(); });
    });
    observer.observe(document.body, { childList: true, subtree: true });
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
    window.addEventListener('popstate', sync);
    sync();
    notify();
    resolve();
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
}) : Promise.resolve();

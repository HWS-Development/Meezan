// Server/prerender imports have no DOM or stylesheet side effects.
export const allowed = () => false;
export const showPreferences = () => false;
export const ready = Promise.resolve();
export const whenAllowed = () => () => {};

# HWS cookie consent

Shared, locally bundled FR/EN consent UI using Vanilla CookieConsent 3.3.0 (MIT).
Import `@hws/cookie-consent` once from the browser entry. Importing during SSR is safe.

Analytics and marketing are disabled by default; necessary preferences expire after
182 days. Accept and reject have equal visual weight. Preferences are accessible
from a button inserted in every semantic footer, including after client navigation.

**Loading this UI alone does not gate an existing tracker.** Register optional
loaders with `whenAllowed('analytics', start)` / `whenAllowed('marketing', start)`.
Guard event emitters with `allowed(category)`. For static script tags, use
`type="text/plain" data-category="analytics"` (or `marketing`). Withdrawal clears
the configured first-party cookies and reloads to stop previously loaded scripts.
Third-party cookies cannot be deleted from this origin. Existing embedded maps and
media need a separate click-to-load policy if the site's policy requires it.

Each client repository vendors `hws-cookie-consent-1.0.0.tgz` at its package root,
with a relative file dependency and lockfile. This keeps CI builds independent of
the parent workspace and avoids loading scripts or CSS from a consent CDN.

To regenerate an archive after updating this source: increment its version, run
`npm pack --pack-destination <client-package-root>`, then install that local archive
in the client. Verify the source/package, build, real requests before consent,
accept/reject/customize, withdrawal, language switching, and mobile layout.
